# 우리집 저녁 뭐 먹지? — 가족 공유형 웹앱

이 프로젝트는 Firebase Realtime Database를 이용해 여러 휴대폰에서 같은 투표 결과를 실시간으로 공유하는 모바일 웹앱입니다.

## 1. Firebase 프로젝트 준비
1. https://console.firebase.google.com 에서 프로젝트를 만듭니다.
2. 프로젝트 설정 > 내 앱 > 웹 앱을 추가하고 Firebase 설정값을 복사합니다.
3. Authentication > 로그인 방법에서 **익명(Anonymous)** 로그인을 사용 설정합니다.
4. Realtime Database를 생성합니다. 데이터베이스 URL을 확인합니다.

## 2. 앱 설정
`index.html`에는 웹 앱 설정값을 미리 넣어 두었습니다. Realtime Database URL(`https://dinner-9177d-default-rtdb.asia-southeast1.firebasedatabase.app`)도 설정해 두었습니다.
`ADMIN_PIN`을 가족끼리 정한 값으로 바꿉니다. 기본값은 반드시 변경하세요.

## 3. Realtime Database 규칙
Firebase Console > Realtime Database > 규칙에 아래 규칙을 적용합니다.

```json
{
  "rules": {
    "familyDinner": {
      ".read": "auth != null",
      ".write": "auth != null"
    }
  }
}
```

이 규칙은 익명 로그인한 사용자가 투표방 데이터를 읽고 쓸 수 있도록 합니다. 링크를 가진 사람은 접근할 수 있으므로 가족끼리만 링크를 공유하세요. 관리자 PIN은 편의용 초기화 잠금이며 강력한 서버 측 관리자 인증은 아닙니다.

## 4. 무료 호스팅(Firebase Hosting)
컴퓨터에 Node.js를 설치한 뒤 프로젝트 폴더에서 다음을 실행합니다.

```bash
npm install -g firebase-tools
firebase login
firebase init hosting
```

초기화 질문에서 기존 프로젝트를 선택하고, public 디렉터리를 현재 폴더(또는 `public`)로 지정합니다. `index.html`을 public 폴더에 둔 뒤:

```bash
firebase deploy
```

배포가 끝나면 `https://프로젝트ID.web.app` 형태의 주소가 표시됩니다. 그 링크를 카카오톡 가족방에 공유하면 됩니다.

## 기능
- 엄마/아빠/첫째/둘째/셋째 이름으로 투표
- 구성원별 한 표 및 투표 변경
- 메뉴 후보 추가
- Firebase 실시간 동기화
- 전원 투표 완료 시 결과 표시
- 관리자 PIN을 통한 투표 초기화
